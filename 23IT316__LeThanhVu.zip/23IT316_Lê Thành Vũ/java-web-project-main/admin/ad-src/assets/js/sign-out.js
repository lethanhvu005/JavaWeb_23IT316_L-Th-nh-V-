$(function() {
    RemoveToken()
    window.location.href = ('/')
    $('.preloader').fadeOut(1000);
})