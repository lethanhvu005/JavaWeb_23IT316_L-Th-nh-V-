package cinema.ticket.booking.model.enumModel;

public enum BookingStatus {
	PENDING,
	BOOKED,
	CANCLED,
}
