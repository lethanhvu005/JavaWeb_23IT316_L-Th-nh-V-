package cinema.ticket.booking.model.enumModel;

public enum UserStatus {
	ACTIVE,
	CLOSED,
	CANCELED,
	BLACKLISTED,
	BLOCKED
}
