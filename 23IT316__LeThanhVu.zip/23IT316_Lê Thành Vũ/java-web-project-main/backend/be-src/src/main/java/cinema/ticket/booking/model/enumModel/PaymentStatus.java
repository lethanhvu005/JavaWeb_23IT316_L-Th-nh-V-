package cinema.ticket.booking.model.enumModel;

public enum PaymentStatus {
	PENDING,
	PAID,
	RETURNED,
	CANCLED
}
