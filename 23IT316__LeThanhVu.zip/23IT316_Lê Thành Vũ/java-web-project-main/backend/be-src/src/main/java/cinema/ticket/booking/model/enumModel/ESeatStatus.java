package cinema.ticket.booking.model.enumModel;

public enum ESeatStatus {
	UNAVAILABLE,
	AVAILABLE,
	PENDING,
	BOOKED,
	CANCLED
}
