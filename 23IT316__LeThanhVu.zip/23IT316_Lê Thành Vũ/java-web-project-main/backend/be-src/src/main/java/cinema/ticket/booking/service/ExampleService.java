package cinema.ticket.booking.service;

public class ExampleService {

}
