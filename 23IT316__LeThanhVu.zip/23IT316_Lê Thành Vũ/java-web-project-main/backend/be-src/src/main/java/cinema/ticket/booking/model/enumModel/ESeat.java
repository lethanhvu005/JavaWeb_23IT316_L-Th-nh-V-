package cinema.ticket.booking.model.enumModel;

public enum ESeat {
	REGULAR,
	PREMIUM
}
